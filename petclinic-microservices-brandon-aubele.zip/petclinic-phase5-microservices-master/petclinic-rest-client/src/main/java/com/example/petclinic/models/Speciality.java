package com.example.petclinic.models;

public enum Speciality {

    NONE, RADIOLOGY, DENTISTRY, SURGERY

}
