package com.example.petclinic.models;

public enum PetType {

    BIRD, CAT, DOG, HAMPSTER, LIZARD, MONKEY, LOBSTER, ELEPHANT, PIG, HORSE, SNAKE

}
